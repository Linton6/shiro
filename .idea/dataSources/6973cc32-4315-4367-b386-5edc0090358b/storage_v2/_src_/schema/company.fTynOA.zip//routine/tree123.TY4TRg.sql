create procedure tree123(IN num char, OUT otatal decimal(8, 2))
  comment 'dasdasdasdad'
  BEGIN
		SELECT Sum(classroom.score)
		FROM classroom
		WHERE `name` = num
		INTO otatal;
END;

