create procedure produce()
  BEGIN
SELECT Avg(classroom.score) AS Average
FROM classroom;
END;

