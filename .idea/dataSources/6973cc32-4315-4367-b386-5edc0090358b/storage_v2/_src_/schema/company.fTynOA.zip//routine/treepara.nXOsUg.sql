create procedure treePara(OUT p1 decimal(8, 2), OUT p2 decimal(8, 2), OUT p3 decimal(8, 2))
  BEGIN
		SELECT Min(classroom.score)
		INTO p1
		FROM classroom;
		SELECT MAX(classroom.score)
		INTO p2
		FROM classroom;
		SELECT Avg(classroom.score)
		INTO p3
		FROM classroom;
END;

