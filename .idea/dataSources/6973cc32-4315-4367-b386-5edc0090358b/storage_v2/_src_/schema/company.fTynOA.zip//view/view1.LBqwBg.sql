create view view1 as
  select `company`.`sex`.`sex_id` AS `sex_id`, `company`.`sex`.`name` AS `name`
  from `company`.`sex`;

