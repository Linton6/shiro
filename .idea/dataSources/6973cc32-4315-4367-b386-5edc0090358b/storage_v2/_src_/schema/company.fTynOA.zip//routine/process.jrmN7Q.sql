create procedure process()
  BEGIN 
		DECLARE peopleName CURSOR
		FOR
		SELECT people.`name` FROM people;
END;

