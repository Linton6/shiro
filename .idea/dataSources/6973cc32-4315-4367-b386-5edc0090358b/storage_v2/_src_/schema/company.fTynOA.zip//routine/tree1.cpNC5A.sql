create procedure tree1(IN num int, OUT otatal decimal(8, 2))
  BEGIN
		SELECT Sum(classroom.score)
		FROM classroom
		WHERE `name` = 'A'
		INTO otatal;
END;

