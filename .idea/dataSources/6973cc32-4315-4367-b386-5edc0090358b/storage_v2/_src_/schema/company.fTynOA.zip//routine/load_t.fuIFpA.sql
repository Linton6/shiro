create procedure load_t(IN count int unsigned)
  BEGIN
 SET @c = 0;
	WHILE @c < count DO
	INSERT INTO t 
	SELECT NULL, REPEAT(CHAR(97 + RAND()*26),10);
	SET @c = @c + 1;
  END WHILE;
	END;

