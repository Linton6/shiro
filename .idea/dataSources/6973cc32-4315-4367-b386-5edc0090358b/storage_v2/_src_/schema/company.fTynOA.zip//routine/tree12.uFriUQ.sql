create procedure tree12(IN num char, OUT otatal decimal(8, 2))
  BEGIN
		SELECT Sum(classroom.score)
		FROM classroom
		WHERE `name` = num
		INTO otatal;
END;

